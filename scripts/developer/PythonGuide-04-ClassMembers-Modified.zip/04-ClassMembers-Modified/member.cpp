#include <string>
#include <sstream>
#include <vector>
#include <iostream>
#include <memory>


#include <boost/python.hpp>
#include <boost/python/list.hpp>
#include <boost/python/suite/indexing/vector_indexing_suite.hpp>



/// @brief Type that allows for registration of conversions from
///        python iterable types.
struct iterable_converter
{
  /// @note Registers converter from a python interable type to the
  ///       provided type.
  template <typename Container>
  iterable_converter&
  from_python()
  {
    boost::python::converter::registry::push_back(
      &iterable_converter::convertible,
      &iterable_converter::construct<Container>,
      boost::python::type_id<Container>());

    // Support chaining.
    return *this;
  }

  /// @brief Check if PyObject is iterable.
  static void* convertible(PyObject* object)
  {
    return PyObject_GetIter(object) ? object : NULL;
  }

  /// @brief Convert iterable PyObject to C++ container type.
  ///
  /// Container Concept requirements:
  ///
  ///   * Container::value_type is CopyConstructable.
  ///   * Container can be constructed and populated with two iterators.
  ///     I.e. Container(begin, end)
  template <typename Container>
  static void construct(
    PyObject* object,
    boost::python::converter::rvalue_from_python_stage1_data* data)
  {
    namespace python = boost::python;
    // Object is a borrowed reference, so create a handle indicting it is
    // borrowed for proper reference counting.
    python::handle<> handle(python::borrowed(object));

    // Obtain a handle to the memory block that the converter has allocated
    // for the C++ type.
    typedef python::converter::rvalue_from_python_storage<Container>
                                                                storage_type;
    void* storage = reinterpret_cast<storage_type*>(data)->storage.bytes;

    typedef python::stl_input_iterator<typename Container::value_type>
                                                                    iterator;

    // Allocate the C++ type into the converter's memory block, and assign
    // its handle to the converter's convertible variable.  The C++
    // container is populated by passing the begin and end iterators of
    // the python object to the container's constructor.
    new (storage) Container(
      iterator(python::object(handle)), // begin
      iterator());                      // end
    data->convertible = storage;
  }
};


 // ============================================================

class SomeClass
{
public:
    SomeClass(std::string n) : name(n), mNumber(0.0) {

      reset_vec();
    }

    std::string name;

    double getNumber() const { return mNumber; }
    void setNumber(double n)
    {
        if (n>3.141592654)
            n = -1;
        mNumber = n;
    }

    std::vector<double> vec1;
    std::vector<double> vec3;
    std::vector< std::vector<double > > vec2d;

    void reset_vec() {
      std::cout << "c++: reset_vec" << std::endl;
      vec1.clear();
      vec1.push_back(11);
      vec1.push_back(13);
      vec1.push_back(15);

      vec3.clear();
      vec3.push_back(2);
      vec3.push_back(4);
      vec3.push_back(6);
      vec3.push_back(8);

      vec2d = std::vector< std::vector<double > > {{1,3,4},{6,7}};
    }
    
    void reset_vec_zero() {
      std::cout << "c++: reset_vec_zero" << std::endl;
      vec1.clear();
      vec1.push_back(0);

      vec3.clear();
      vec3.push_back(0);

      vec2d = std::vector< std::vector<double > > {{0,0},{0,0}};
    }

    void show_vec1() {
      std::cout << "c++: show_vec1" << std::endl;
      for (unsigned int i = 0; i < vec1.size(); ++i) {
        std::cout << vec1[i] << " ";
      }
      std::cout << std::endl;
    }

    void show_vec3() {
      std::cout << "c++: show_vec3" << std::endl;
      for (unsigned int i = 0; i < vec3.size(); ++i) {
        std::cout << vec3[i] << " ";
      }
      std::cout << std::endl;
    }

    void show_vec2d() {
      std::cout << "c++: show_vec2d" << std::endl;
      for (unsigned int i = 0; i < vec2d.size(); ++i) {
        for (unsigned int j = 0; j < vec2d[i].size(); ++j) {
          std::cout << vec2d[i][j] << " ";
        }
        std::cout << std::endl;
      }
      std::cout << std::endl;
    }



    boost::python::list get_vec1() {   
      std::cout << "c++: get_vec1" << std::endl;
      boost::python::list list;
      for (int i = 0; i < vec1.size(); ++i) {
          list.append(vec1[i]);
      }
      return list;
    }

    boost::python::list get_vec3() {   
      std::cout << "c++: get_vec3" << std::endl;
      boost::python::list list;
      for (int i = 0; i < vec3.size(); ++i) {
          list.append(vec3[i]);
      }
      return list;
    }

    std::vector<double> get_vec3t2() {   
      std::cout << "c++: get_vec3t2" << std::endl;
      return vec3;
    }


    boost::python::list get_vec2d() {   
      std::cout << "c++: get_vec2d" << std::endl;
      boost::python::list list;
      for (int i = 0; i < vec2d.size(); ++i) {
        boost::python::list listtmp;
        for (int j = 0; j < vec2d[i].size(); ++j) {
          listtmp.append(vec2d[i][j]);
        }
        list.append(listtmp);
      }
      return list;
    }


    void set_vec1(boost::python::list& ns) {   
      std::cout << "c++: set_vec1" << std::endl;
      vec1.resize(len(ns)); 
      for (int i = 0; i < len(ns); ++i) 
      { 
        vec1[i] = boost::python::extract<double>(ns[i]); 
      } 
    }

    void set_vec3(boost::python::list& ns) {   
      std::cout << "c++: set_vec3" << std::endl;
      vec3.resize(len(ns)); 
      for (int i = 0; i < len(ns); ++i) 
      { 
        vec3[i] = boost::python::extract<double>(ns[i]); 
      } 
    }

    std::vector<double> set_vec3t2() {   
      std::cout << "c++: set_vec3t2" << std::endl;
      return vec3;
    }

    void set_vec2d(const std::vector< std::vector<double > > &v) {   
      std::cout << "c++: set_vec2d" << std::endl;
      vec2d.resize(v.size());
      for (int i = 0; i < v.size(); ++i) {
        vec2d[i].resize(v[i].size());
        for (int j = 0; j < v[i].size(); ++j) {
          vec2d[i][j] = v[i][j];
        }
        
      }
/*
      vec.resize(len(ns)); 
      for (int i = 0; i < len(ns); ++i) 
      { 
        vec[i].resize(len(ns)); 
        vec[i] = boost::python::extract<double>(ns[i]); 
      } 
*/
    }


private:
    double mNumber;
};


class Base {
public:
  Base(std::string msg) {
    m=0; 
    n = 0;
    mMsg= msg;
  }
  double m, n;
  std::string mMsg;
};

class Derived : public Base {
public:
  Derived (std::string msg) : Base(msg) {
    m = 1;
    n = 1;    
    mMsg= msg;
  }

};

class Other {

public:

  Other(std::string msg) {
     mMsg= msg;
     base_ptr = nullptr;
     derived_ptr = nullptr;
     base_sh_ptr = nullptr;    
     derived_sh_ptr = nullptr;
  }

  void show_base_ptr() {
    std::cout << "show_base_ptr " << std::endl;
    if (base_ptr == nullptr) 
      std::cout << "it is nullptr" << std::endl;
    else
      std::cout << base_ptr -> mMsg << " m = " << base_ptr -> m  << " , n = " << base_ptr -> n << std::endl;
  }

  void show_derived_ptr() {
    std::cout << "show_derived_ptr" << std::endl;
    if (derived_ptr == nullptr) 
      std::cout << "it is nullptr" << std::endl;
    else
    std::cout << derived_ptr -> mMsg<< " m = " << derived_ptr -> m  << " , n = " << derived_ptr -> n << std::endl;
  }

  void show_base_sh_ptr() {
    std::cout << "show_base_sh_ptr" << std::endl;
    if (base_sh_ptr== nullptr) 
      std::cout << "it is nullptr" << std::endl;
    else
    std::cout << base_sh_ptr -> mMsg << " m = " << base_sh_ptr -> m  << " , n = " << base_sh_ptr -> n << std::endl;
  }

  void show_derived_sh_ptr() {
    std::cout << "show_derived_sh_ptr" << std::endl;
    if (derived_sh_ptr== nullptr) 
      std::cout << "it is nullptr" << std::endl;
    else
      std::cout << derived_sh_ptr -> mMsg << " m = " << derived_sh_ptr -> m  << " , n = " << derived_sh_ptr -> n << std::endl;
  }

  void  set_base_ptr (std::shared_ptr<Base> ptr) {
    base_ptr = ptr.get();
  }


  std::shared_ptr<Base> get_base_ptr () const {
    //return std::make_shared<Base> (base_ptr, base_ptr->mMsg);
  }


  void  set_base_sh_ptr (std::shared_ptr<Base> ptr) {
   base_sh_ptr = ptr;
  }

  std::shared_ptr<Base> get_base_sh_ptr () const {
    return base_sh_ptr;
  }
//-----------------------------------------------------------
  void set_base_ptr_by_function1 (const Base* b) {
    //base_ptr = b; // COMPILE ERROR
  }

  void set_base_ptr_by_function2 (const std::shared_ptr<Base> &b) {
    base_ptr = b.get(); // WORKING
  }

  void set_base_sh_ptr_by_function1 (const Base *b) {
    //base_sh_ptr = std::make_shared<Base>(b); // COMPILE ERROR
  }

  void set_base_sh_ptr_by_function2 (const std::shared_ptr<Base> &b) {
    base_sh_ptr = b; // WORkING
  }
//-----------------------------------------------------------

  Base * base_ptr;
  Derived * derived_ptr;

  std::shared_ptr<Base> base_sh_ptr;
  std::shared_ptr<Derived> derived_sh_ptr;

  std::string mMsg;
};

#include <boost/python.hpp>

using namespace boost::python;

BOOST_PYTHON_MODULE(member)
{

  implicitly_convertible<std::shared_ptr<Derived>,          
                         std::shared_ptr<Base> >(); 


  class_<Base>("Base", init<std::string>())
    .def_readwrite("mMsg", & Base::mMsg)
    .def_readwrite("m", & Base::m)
    .def_readwrite("n", & Base::n)
  ;

  class_<Derived>("Derived", init<std::string>())
    .def_readwrite("mMsg", & Derived::mMsg) 
    .def_readwrite("m", & Derived::m)
    .def_readwrite("n", & Derived::n)

  ;

  class_<Other>("Other", init<std::string>())
    .def_readwrite("mMsg", & Other::mMsg) 

    .def_readwrite("base_ptr", & Other::base_ptr)
    .def_readwrite("base_sh_ptr", & Other::base_sh_ptr)

    .def("set_base_ptr_by_function1", & Other::set_base_ptr_by_function1)
    .def("set_base_ptr_by_function2", & Other::set_base_ptr_by_function2)
    .def("set_base_sh_ptr_by_function1", & Other::set_base_sh_ptr_by_function1)
    .def("set_base_sh_ptr_by_function2", & Other::set_base_sh_ptr_by_function2)

    //.add_property("sg_base_ptr", &Other::get_base_ptr,&Other::set_base_ptr)
    //.add_property("sg_base_ptr2", &Other::get_base_ptr2,&Other::set_base_ptr)
    .add_property("sg_base_sh_ptr", &Other::get_base_sh_ptr,&Other::set_base_sh_ptr)
    .def("show_base_ptr", &Other::show_base_ptr)
    .def("show_derived_ptr", &Other::show_derived_ptr)
    .def("show_base_sh_ptr", &Other::show_base_sh_ptr)
    .def("show_derived_sh_ptr", &Other::show_derived_sh_ptr)  
  ;

  //register_ptr_to_python<Base*>();
  //register_ptr_to_python<Derived*>();

  // Register interable conversions.
  iterable_converter()
    // Build-in type.
    .from_python<std::vector<double> >()
    // Each dimension needs to be convertable.
    .from_python<std::vector<std::string> >()
    .from_python<std::vector<std::vector<double> > >() // used for setter vec2d
    // User type.
    ;


   class_<std::vector<double>>("stdvector")
        .def(vector_indexing_suite<std::vector<double>>() );

   class_<std::vector<std::vector<double>>>("stdvector<stdvector>")
        .def(vector_indexing_suite<std::vector<std::vector<double>>>() );

    class_<SomeClass>("SomeClass", init<std::string>())
        .def_readwrite("name", & SomeClass::name) // ORIGINAL
        .add_property("number", &SomeClass::getNumber, &SomeClass::setNumber) // ORIGINAL

        .def("reset_vec", &SomeClass::reset_vec)
        .def("reset_vec_zero", &SomeClass::reset_vec_zero)

        .def("show_vec1", & SomeClass::show_vec1)
        .def("show_vec3", & SomeClass::show_vec3)
        .def("show_vec2d", & SomeClass::show_vec2d)

        .def_readwrite("vec1", & SomeClass::vec1)
        .def_readwrite("vec3", & SomeClass::vec3)
        .def_readwrite("vec2d", & SomeClass::vec2d)

        .add_property("gsvec1", &SomeClass::get_vec1,&SomeClass::set_vec1)
        .add_property("gsvec3", &SomeClass::get_vec3, &SomeClass::set_vec3)
        .add_property("gsvec3t2", &SomeClass::get_vec3t2, &SomeClass::set_vec3t2)
        .add_property("gsvec2d", &SomeClass::get_vec2d, &SomeClass::set_vec2d)

/*      

*/
    ;


}


