#!/usr/bin/env python

import member

m1 = member.SomeClass("Pavel")
print ("name =",m1.name)
m1.name = "Gunther"
print ("name =",m1.name)


m1.number = 7.3
print ("number =",m1.number)

