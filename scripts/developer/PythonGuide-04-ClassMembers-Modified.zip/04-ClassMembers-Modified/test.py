
import member
m1 = member.SomeClass("Pavel")
print ("name =",m1.name)
m1.name = "Gunther"
print ("name =",m1.name)
m1.number = 7.3
print ("number =",m1.number)
print ("reset_vec")
m1.reset_vec()

m1.show_vec1()
m1.show_vec3()
m1.show_vec2d()

m1.reset_vec_zero()

m1.show_vec1()
m1.show_vec3()
m1.show_vec2d()

m1.reset_vec()

print ("m1.vec1()")
m1.vec1=[1,2,3]
print (m1.vec1)
print ("done")

print ("m1.vec3()")
m1.vec3
print (m1.vec3)
print ("done")

print ("m1.vec2d()")
m1.vec2d=[[51.0, 53.0, 54.0], [56.0, 57.0, 59.0]]
print (m1.vec2d)
print ("done")

print ("m1.gsvec1()")
m1.gsvec1
print (m1.gsvec1)
print ("done")

print ("m1.gsvec3()")
m1.gsvec3
print (m1.gsvec3)
print ("done")

print ("m1.gsvec2d()")
m1.gsvec2d
print (m1.gsvec2d)
print ("done")

m1.show_vec1()
m1.show_vec3()
print ("m1.vec1 = m1.vec3")
m1.vec1=m1.vec3
m1.show_vec1()
m1.show_vec3()
m1.vec3[0]=99
print ("m1.vec3[0] = 99")
m1.show_vec1()
m1.show_vec3()


print ("m1.gsvec2d()")
m1.gsvec2d
print (m1.gsvec2d)
print ("done")

print ("m1.gsvec2d=[[11,11,22],[11,3]]")
m1.gsvec2d=[[11,11,22],[11,3]]
print (m1.gsvec2d)
print ("done")

