
import member

base1 = member.Base("Hi-i-am-Base 1 ");
base2 = member.Base("Hi-i-am-Base 2 ");
derived1 = member.Derived("Hi-i-am-Derived 1");
derived2 = member.Derived("Hi-i-am-Derived 2");
other = member.Other("Hi-i-am-other ");

print("base1.m", base1.m)
print("base1.n", base1.n)
print("base1.mMsg", base1.mMsg)
print("")
print("derived1.m", derived1.m)
print("derived1.m", derived1.n)
print("derived1.mMsg", derived1.mMsg)
print("")
print("other.mMsg", other.mMsg)
print("")

other.base_ptr=base1
other.base_sh_ptr=base1

other.show_base_ptr()
other.show_base_sh_ptr()

other.sg_base_ptr = derived1
other.sg_base_sh_ptr = derived1

other.show_base_ptr()
other.show_base_sh_ptr()


other.show_derived_ptr()
other.show_derived_sh_ptr()

base1 = member.Base("Hi-i-am-Base 1 ");
base2 = member.Base("Hi-i-am-Base 2 ");

print ("======================================= 1 ")
other.set_base_ptr_by_function1(base1)
other.show_base_ptr()
other.set_base_ptr_by_function1(base2)
other.show_base_ptr()

print ("======================================= 2 ")

other.set_base_ptr_by_function2(base1)
other.show_base_ptr()
other.set_base_ptr_by_function2(base2)
other.show_base_ptr()

print ("======================================= 3 ")
other.set_base_sh_ptr_by_function1(base1)
other.show_base_sh_ptr()
other.set_base_sh_ptr_by_function1(base2)
other.show_base_sh_ptr()

print ("======================================= 4 ")
other.set_base_sh_ptr_by_function2(base1)
other.show_base_sh_ptr()
other.set_base_sh_ptr_by_function2(base2)
other.show_base_sh_ptr()

print ("======================================= 5 ")
other.set_base_sh_ptr_by_function2(derived1)
other.show_base_sh_ptr()
other.set_base_sh_ptr_by_function2(derived2)
other.show_base_sh_ptr()

